import { Router } from "express";
import { authMiddleware } from "@middlewares/auth.middleware";
import { userOnly } from "@middlewares/user.middleware";
import { reservationController } from "@controllers/reservation.controller";

const router = Router();

router.use(authMiddleware, userOnly);

router.get("/dashboard", (req, res) => {
  res.render("user/dashboard", { user: req.user });
});


export default router;
