import { Router } from "express";
import { userController } from "@controllers/user.controller";
import { authMiddleware } from "@middlewares/auth.middleware";
import { userOnly } from "@middlewares/user.middleware";

const router = Router();

router.use(authMiddleware, userOnly);

router.get("/profile", userController.getProfile);
router.get("/screenings", userController.getScreenings);
router.get("/reservations", userController.getMyReservations);
router.post("/reservations", userController.createReservation);
router.delete("/reservations/:id", userController.cancelReservation);

export default router;
