import { Payment } from "@models/payment.model";

export type PaymentStatus =
  | "ZAINICJOWANA"
  | "W TRAKCIE"
  | "OPŁACONA"
  | "NIEUDANA"
  | "ZWRÓCONO";

export type PaymentProvider = "KARTA" | "PRZELEW" | "BLIK" | "GOTÓWKA";

export class PaymentRepository {
  findAll() {
    return Payment.find();
  }

  findById(id: string) {
    return Payment.findById(id);
  }

  create(provider: PaymentProvider) {
    return Payment.create({
      provider,
      status: "ZAINICJOWANA",
    });
  }

  updateStatus(id: string, status: PaymentStatus) {
    return Payment.findByIdAndUpdate(
      id,
      { status },
      { new: true, runValidators: true }
    );
  }

  delete(id: string) {
    return Payment.findByIdAndDelete(id);
  }
}

export const paymentRepository = new PaymentRepository();
