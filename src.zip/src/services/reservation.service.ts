import { reservationRepository } from "@repositories/reservation.repository";
import { Screening } from "@models/screening.model";
import { seatRepository } from "@repositories/seat.repository";

export class ReservationService {
  async createReservation(data: {
    user_id: string;
    screening_id: string;
    ticket_id?: string;
    seats_id: string;
  }) {
    // 🔒 sprawdzenie czy miejsce jest wolne
    const existingReservation =
      await reservationRepository.findByScreeningAndSeat(
        data.screening_id,
        data.seats_id
      );

    if (existingReservation) {
      throw new Error("SEAT_ALREADY_RESERVED");
    }

    return reservationRepository.create(data);
  }

  async getReservation(id: string) {
    return reservationRepository.findById(id);
  }

  async cancelReservation(id: string) {
    const reservation = await reservationRepository.findById(id);
    if (!reservation) {
      throw new Error("RESERVATION_NOT_FOUND");
    }

    await reservationRepository.delete(id);
    return true;
  }
  async getAvailableSeatsForScreening(screeningId: string) {
    const screening = await Screening.findById(screeningId);
    if (!screening) {
      throw new Error("SCREENING_NOT_FOUND");
    }

    // wszystkie miejsca w sali
    const allSeats = await seatRepository.findByHall(
      screening.hall_id.toString()
    );

    // zajęte miejsca w tym seansie
    const reservations = await reservationRepository.findAll();
    const takenSeatIds = reservations
      .filter((r) => r.screening_id.toString() === screeningId)
      .map((r) => r.seats_id.toString());

    // tylko wolne
    return allSeats.filter(
      (seat) => !takenSeatIds.includes(seat._id.toString())
    );
  }
}

export const reservationService = new ReservationService();
